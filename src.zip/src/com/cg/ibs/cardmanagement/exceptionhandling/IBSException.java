package com.cg.ibs.cardmanagement.exceptionhandling;

@SuppressWarnings("serial")
public class IBSException  extends Exception{

	
	public IBSException(String s) 
    { 
        super(s); 
    } 
}