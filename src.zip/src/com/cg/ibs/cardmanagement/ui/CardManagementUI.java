package com.cg.ibs.cardmanagement.ui;

import java.util.*;

import com.cg.ibs.cardmanagement.bean.CaseIdBean;
import com.cg.ibs.cardmanagement.bean.CreditCardBean;
import com.cg.ibs.cardmanagement.bean.CreditCardTransaction;
import com.cg.ibs.cardmanagement.bean.DebitCardBean;
import com.cg.ibs.cardmanagement.bean.DebitCardTransaction;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;
import com.cg.ibs.cardmanagement.service.BankService;
import com.cg.ibs.cardmanagement.service.BankServiceClassImpl;
import com.cg.ibs.cardmanagement.service.CustomerService;
import com.cg.ibs.cardmanagement.service.CustomerServiceImpl;

import java.math.BigInteger;

public class CardManagementUI {

	static BigInteger accountNumber = null;
	static Scanner scan;
	static BigInteger debitCardNumber = null;
	static BigInteger creditCardNumber = null;
	static String transactionId;
	static boolean success = false;
	static int myChoice = 0;
	static int pin;
	CustomerService customService = new CustomerServiceImpl();
	BankService bankService = new BankServiceClassImpl();

	public void listDebitCards() {
		List<DebitCardBean> debitCardBeans = customService.viewAllDebitCards();
		if (debitCardBeans.isEmpty()) {
			System.out.println("No Existing Debit Cards");
		} else {
			for (DebitCardBean debitCardBean : debitCardBeans) {
				System.out.println(debitCardBean);
			}
		}
	}

	public void listCreditCards() {
		List<CreditCardBean> creditCardBeans = customService.viewAllCreditCards();
		if (creditCardBeans.isEmpty()) {
			System.out.println("No Existing Credit Cards");
		} else {
			for (CreditCardBean creditCardBean : creditCardBeans) {
				System.out.println(creditCardBean);
			}
		}
	}

	public void applyNewDebitCard() {
		success = false;
		System.out.println("You are applying for a new Debit Card");
		while (!success) {

			try {
				System.out.println("Enter Account Number you want to apply debit card for :");

				accountNumber = scan.nextBigInteger();

				success = true;
			} catch (InputMismatchException wrongFormat) {

				scan.next();
				System.out.println("Renter 10 digit account number");
			}
		}

		boolean result = customService.applyNewDebitCard(accountNumber);
		System.out.println(result);
		if (result) {
			System.out.println(" Debit Card applied successfully");
		} else {
			System.out.println("Account Number Entered wrong");
		}
	}

	public void applyNewCreditCard() {
		System.out.println("You are applying for a new Credit Card");
		customService.applyNewCreditCard();
		System.out.println("New Credit Card applied successfully");
	}

	public void upgradeExistingDebitCard() {
		success = false;
		System.out.println("Enter your Debit Card Number: ");
		while (!success) {

			try {

				debitCardNumber = scan.nextBigInteger();
				System.out.println(debitCardNumber);
				success = true;
			} catch (InputMismatchException wrongFormat) {
				scan.next();
				System.out.println("Enter a valid Debit card number");
			}
		}
		String type = customService.verifyDebitcardType(debitCardNumber);
		System.out.println("Your debit card is:" + type);

		if (type.equals("Silver")) {
			System.out.println("Choose 1 to upgrade to Gold");
			System.out.println("Choose 2 to upgrade to Platinum");

			success = false;
			while (!success) {
				try {
					myChoice = scan.nextInt();
					success = true;
				} catch (InputMismatchException wrongFormat) {
					scan.next();
					System.out.println("Choose between 1 or 2");

				}
			}
			customService.requestDebitCardUpgrade(debitCardNumber, myChoice);

		} else if (type.equals("Gold")) {
			System.out.println("Choose 2 to upgrade to Platinum");
			success = false;
			while (!success) {
				try {
					myChoice = scan.nextInt();
					success = true;
				} catch (InputMismatchException wrongFormat) {
					scan.next();
					System.out.println("Enter 2 to upgrade");
				}
			}
			customService.requestDebitCardUpgrade(debitCardNumber, myChoice);

		} else {
			System.out.println("You already have a Platinum Card");
		}
	}

	public void upgradeExistingCreditCard() {
		System.out.println("Enter your Credit Card Number: ");
		while (!success) {

			int myChoice1;
			try {
				creditCardNumber = scan.nextBigInteger();
				success = true;
			} catch (InputMismatchException wrongFormat) {

				scan.next();
				System.out.println("Renter  credit  number");

			}
			String type1 = customService.verifyCreditcardType(creditCardNumber);
			System.out.println("Your credit card is:" + type1);

			if (type1.equals("Silver")) {
				System.out.println("Choose 1 to upgrade to Gold");
				System.out.println("Choose 2 to upgrade to Platinum");
				myChoice1 = scan.nextInt();
				customService.requestCreditCardUpgrade(creditCardNumber, myChoice1);

			} else if (type1.equals("Gold")) {
				System.out.println("Choose 2 to upgrade to Platinum");
				myChoice1 = scan.nextInt();
				customService.requestCreditCardUpgrade(creditCardNumber, myChoice1);

			} else {
				System.out.println("You already have a Platinum Card");
			}
		}
	}

	public void resetDebitCardPin() {
		success = false;
		System.out.println("Enter your Debit Card Number: ");

		while (!success) {

			try {
				debitCardNumber = scan.nextBigInteger();
				success = true;
			} catch (InputMismatchException wrongFormat) {
				scan.next();
				System.out.println("Enter a valid debit card number");
			}

		}

		boolean check = customService.verifyDebitCardNumber(debitCardNumber);
		if (check) {
			System.out.println("Enter your existing pin:");

			success = false;
			while (!success) {
				try {

					pin = scan.nextInt();

					if (customService.getPinLength(pin) != 4)
						throw new IBSException("Incorrect Length of pin ");
					getNewPin(pin, debitCardNumber);

					// cll function below to set new pin
					success = true;
				} catch (InputMismatchException wrongFormat) {
					System.out.println("Enter a valid 4 digit pin");
					scan.next();

				} catch (IBSException ExceptionObj) {
					System.out.println(ExceptionObj.getMessage());
					scan.next();

				}
			}

		}
	}

	public void resetCreditCardPin() {
		success = false;
		System.out.println("Enter your Credit Card Number: ");
		while (!success) {
			try {
				creditCardNumber = scan.nextBigInteger();
				success = true;
			} catch (InputMismatchException wrongFormat) {
				scan.next();
				System.out.println("Enter a valid credit card number");
			}
		}
		boolean check1 = customService.verifyCreditCardNumber(creditCardNumber);
		if (check1) {
			System.out.println("Enter your existing pin:");
			success = false;
			while (!success) {
				try {

					int pin = scan.nextInt();

					if (customService.getPinLength(pin) != 4)
						throw new IBSException("Incorrect Length of pin ");
					getNewPin2(pin, creditCardNumber);
					// cll function below to set new pin
					success = true;
				} catch (InputMismatchException wrongFormat) {
					System.out.println("Enter a valid 4 digit pin");
					scan.next();

				} catch (IBSException ExceptionObj) {
					System.out.println(ExceptionObj.getMessage());
					scan.next();

				}
			}

		}
	}

	public void reportCreditCardLost() {
		success = false;
		while (!success) {

			try {
				System.out.println("Enter your Credit Card Number: ");
				creditCardNumber = scan.nextBigInteger();
				success = true;
			} catch (InputMismatchException wrongFormat) {

				System.out.println("Not a valid format");
				scan.next();
			}
		}
		boolean result2 = customService.requestCreditCardLost(creditCardNumber);
		if (result2) {
			System.out.println("Ticket raised successfully");
		} else {
			System.out.println("Invalid Credit card number");
		}
	}

	public void reportDebitCardLost() {
		success = false;
		while (!success) {

			try {
				System.out.println("Enter your Debit Card Number: ");
				debitCardNumber = scan.nextBigInteger();
				success = true;
			} catch (InputMismatchException wrongFormat) {

				System.out.println("Not a valid format");
				scan.next();
			}
		}
		boolean result1 = customService.requestDebitCardLost(debitCardNumber);
		if (result1) {
			System.out.println("Ticket raised successfully");
		} else {
			System.out.println("Invalid debit card number");
		}
	}

	public void requestDebitCardStatement() {
		success = false;
		int days = 0;
		while (!success) {

			try {
				System.out.println("Enter your Debit Card Number: ");
				debitCardNumber = scan.nextBigInteger();
				success = true;
			} catch (InputMismatchException wrongFormat) {
				scan.next();
				System.out.println("Not a valid format");
			}
		}
		success = false;

		while (!success) {
			try {
				System.out.println("enter days : ");
				days = scan.nextInt();
				success = true;
			} catch (InputMismatchException wrongFormat) {
				scan.next();
				System.out.println("Not a valid format");
			}
		}

		try {
			List<DebitCardTransaction> debitCardBeanTrns = customService.getDebitTrns(days, debitCardNumber);
			for (DebitCardTransaction debitCardTrns : debitCardBeanTrns)
				System.out.println(debitCardTrns.toString());
		}

		catch (Exception e) {
			System.out.println("invalid date format or debit card does not exist");
		}
	}

	public void requestCreditCardStatement() {
		success = false;
		int days1 = 0;
		while (!success) {

			try {
				System.out.println("Enter your Credit Card Number: ");
				creditCardNumber = scan.nextBigInteger();
				success = true;
			} catch (InputMismatchException wrongFormat) {
				scan.next();
				System.out.println("Not a valid format");
			}
		}
		success = false;

		while (!success) {
			try {
				System.out.println("enter days : ");
				days1 = scan.nextInt();
				success = true;
			} catch (InputMismatchException wrongFormat) {
				scan.next();
				System.out.println("Not a valid format");
			}
		}

		try {
			List<CreditCardTransaction> creditCardBeanTrns = customService.getCreditTrans(days1, creditCardNumber);
			for (CreditCardTransaction creditCardTrns : creditCardBeanTrns)
				System.out.println(creditCardTrns.toString());
		}

		catch (Exception e) {
			System.out.println("invalid date format or debit card does not exist");
		}
	}

	public void reportDebitStatementMismatch() {
		success = false;
		while (!success) {

			try {

				System.out.println("Enter your transaction id");
				transactionId = scan.next();
				success = true;
			} catch (InputMismatchException wrongFormat) {
				scan.next();
				System.out.println("Not a valid format");
			}
		}
		boolean result3 = customService.raiseDebitMismatchTicket(transactionId);
		if (result3) {
			System.out.println(" Ticket Raised successfully");
		} else {
			System.out.println("Invalid transaction id");
		}
	}

	public void reportCreditStatementMismatch() {
		success = false;
		while (!success) {

			try {

				System.out.println("Enter your transaction id");
				transactionId = scan.next();
				success = true;
			} catch (InputMismatchException wrongFormat) {
				scan.next();
				System.out.println("Not a valid format");
			}
		}
		boolean result4 = customService.raiseCreditMismatchTicket(transactionId);
		if (result4) {
			System.out.println(" Ticket Raised successfully");
		} else {
			System.out.println("Invalid transaction id");
		}
	}

	public void customerLogOut() {
		System.out.println("LOGGED OUT");

	}

	public void listQueries() {
		List<CaseIdBean> caseBeans = bankService.viewQueries();
		if (caseBeans.isEmpty()) {
			System.out.println("No Existing Queries");
		} else {

			for (CaseIdBean caseId : caseBeans) {

				System.out.println(caseId.toString());
			}
		}
	}

	public void replyQueries() {
		String queryId = null;
		String newStatus = null;
		success = false;
		while (!success) {
			try {
				System.out.println("Enter query ID ");
				queryId = scan.next();
				success = true;
			} catch (InputMismatchException wrongFormat) {
				scan.next();
				System.out.println("Not a valid format");
			}
		}
		if (bankService.verifyQueryId(queryId)) {
			success = false;
			// while (!success)
			try {
				System.out.println("Enter new Status");
				newStatus = scan.next();
			} catch (InputMismatchException wrongFormat) {
				scan.next();
				System.out.println("Not a valid format");
			}

			bankService.setQueryStatus(queryId, newStatus);

		} else {
			System.out.println("Invalid query id");
		}
	}

	// break;
	public void viewBankDebitCardStatment() {
		success = false;
		int days = 0;
		while (!success) {

			try {
				System.out.println("Enter your Debit Card Number: ");
				debitCardNumber = scan.nextBigInteger();
				success = true;
			} catch (InputMismatchException wrongFormat) {
				scan.next();
				System.out.println("Not a valid format");
			}
		}
		success = false;

		while (!success) {
			try {
				System.out.println("enter days : ");
				days = scan.nextInt();
				success = true;
			} catch (InputMismatchException wrongFormat) {
				scan.next();
				System.out.println("Not a valid format");
			}
		}

		try {
			List<DebitCardTransaction> debitCardBeanTrns = bankService.getDebitTrns(days, debitCardNumber);
			for (DebitCardTransaction debitCardTrns : debitCardBeanTrns)
				System.out.println(debitCardTrns.toString());
		}

		catch (Exception e) {
			System.out.println("invalid date format or debit card does not exist");
		}
	}

	public void viewBankCreditCardStatment() {
		success = false;
		int days1 = 0;
		while (!success) {

			try {
				System.out.println("Enter your Credit Card Number: ");
				creditCardNumber = scan.nextBigInteger();
				success = true;
			} catch (InputMismatchException wrongFormat) {
				scan.next();
				System.out.println("Not a valid format");
			}
		}
		success = false;

		while (!success) {
			try {
				System.out.println("enter days : ");
				days1 = scan.nextInt();
				success = true;
			} catch (InputMismatchException wrongFormat) {
				scan.next();
				System.out.println("Not a valid format");
			}
		}

		try {
			List<CreditCardTransaction> creditCardBeanTrns = bankService.getCreditTrans(days1, creditCardNumber);
			for (CreditCardTransaction creditCardTrns : creditCardBeanTrns)
				System.out.println(creditCardTrns.toString());
		}

		catch (Exception e) {
			System.out.println("invalid date format or debit card does not exist");
		}
	}

	public void bankLogOut() {
		System.out.println("LOGGED OUT");
	}

	private void getNewPin(int pin2, BigInteger debitCardNumber) {
		if (customService.verifyDebitPin(pin, debitCardNumber)) {
			System.out.println("Enter new pin");
			success = false;
			while (!success) {
				try {

					pin = scan.nextInt();

					if (customService.getPinLength(pin) != 4)
						throw new IBSException("Incorrect Length of pin ");
					System.out.println(customService.resetDebitPin(debitCardNumber, pin));
					success = true;
				} catch (InputMismatchException wrongFormat) {
					System.out.println("Enter a valid 4 digit pin");
					scan.next();

				} catch (IBSException ExceptionObj) {
					System.out.println(ExceptionObj.getMessage());
					scan.next();

				}
			}

		} else {

			System.out.println("You have entered wrong pin ");
			System.out.println("Try again");
		}

	}

	private void getNewPin2(int pin2, BigInteger creditCardNumber) {
		if (customService.verifyCreditPin(pin, creditCardNumber)) {
			System.out.println("Enter new pin");
			success = false;
			while (!success) {
				try {

					int pin = scan.nextInt();

					if (customService.getPinLength(pin) != 4)
						throw new IBSException("Incorrect Length of pin ");
					System.out.println(customService.resetCreditPin(creditCardNumber, pin));
					success = true;
				} catch (InputMismatchException wrongFormat) {
					System.out.println("Enter a valid 4 digit pin");
					scan.next();

				} catch (IBSException ExceptionObj) {
					System.out.println(ExceptionObj.getMessage());
					scan.next();

				}
			}

		} else {

			System.out.println("You have entered wrong pin ");
			System.out.println("Try again");
		}

	}

	public void doIt() {
		while (true) {

			System.out.println("Welcome to card management System");
			System.out.println("Enter 1 to login as a customer");
			System.out.println("Enter 2 to login as a bank admin");

			int userInput = scan.nextInt();

			if (userInput == 1) {
				System.out.println("You are logged in as a customer");
				CustomerMenu choice = null;
				while (choice != CustomerMenu.CUSTOMER_LOG_OUT) {
					System.out.println("Menu");
					System.out.println("--------------------");
					System.out.println("Choice");
					System.out.println("--------------------");
					for (CustomerMenu mmenu : CustomerMenu.values()) {
						System.out.println(mmenu.ordinal() + "\t" + mmenu);
					}
					System.out.println("Choice");
					int ordinal = scan.nextInt();
					if (ordinal >= 0 && ordinal < 15) {
						choice = CustomerMenu.values()[ordinal];

						BigInteger creditCardNumber = null;
						switch (choice) {

						case LIST_EXISTING_DEBIT_CARDS:

							listDebitCards();
							break;

						case LIST_EXISTING_CREDIT_CARDS:

							listCreditCards();
							break;

						case APPLY_NEW_DEBIT_CARD:

							applyNewDebitCard();
							break;
						case APPLY_NEW_CREDIT_CARD:

							applyNewCreditCard();
							break;

						case UPGRADE_EXISTING_DEBIT_CARD:

							upgradeExistingDebitCard();
							break;

						case UPGRADE_EXISTING_CREDIT_CARD:

							upgradeExistingCreditCard();
							break;

						case RESET_DEBIT_CARD_PIN:

							resetDebitCardPin();
							break;

						case RESET_CREDIT_CARD_PIN:

							resetCreditCardPin();
							break;

						case REPORT_DEBIT_CARD_LOST:

							reportDebitCardLost();
							break;

						case REPORT_CREDIT_CARD_LOST:

							reportCreditCardLost();
							break;

						case REQUEST_DEBIT_CARD_STATEMENT:

							requestDebitCardStatement();
							break;

						case REQUEST_CREDIT_CARD_STATEMENT:

							requestCreditCardStatement();
							break;

						case REPORT_DEBITCARD_STATEMENT_MISMATCH:

							reportDebitStatementMismatch();
							break;

						case REPORT_CREDITCARD_STATEMENT_MISMATCH:

							reportCreditStatementMismatch();
							break;

						case CUSTOMER_LOG_OUT:

							customerLogOut();
						}
					}

				}
			} else {
				if (userInput == 2) {

					System.out.println("You are logged in as a Bank Admin");
					BankMenu cchoice = null;
					while (cchoice != BankMenu.BANK_LOG_OUT) {
						System.out.println("Menu");
						System.out.println("--------------------");
						System.out.println("Choice");
						System.out.println("--------------------");
						for (BankMenu mmenu : BankMenu.values()) {
							System.out.println(mmenu.ordinal() + "\t" + mmenu);
						}
						System.out.println("Choice");
						int ordinal1 = scan.nextInt();
						if (ordinal1 >= 0 && ordinal1 < BankMenu.values().length) {
							cchoice = BankMenu.values()[ordinal1];

							switch (cchoice) {

							case LIST_QUERIES:

								listQueries();
								break;

							case REPLY_QUERIES:

								replyQueries();
								break;

							case VIEW_DEBIT_CARD_STATEMENT:

								viewBankDebitCardStatment();
								break;

							case VIEW_CREDIT_CARD_STATEMENT:

								viewBankCreditCardStatment();
								break;

							case BANK_LOG_OUT:

								bankLogOut();
								break;

							}
						}
					}
				} else {
					System.out.println("Invalid Option!!");

				}

			}

		}
	}

	public static void main(String args[]) throws Exception {
		scan = new Scanner(System.in);
		CardManagementUI obj = new CardManagementUI();
		obj.doIt();
		System.out.println("Program End");
		obj.scan.close();
	}
}